/*
 * nema17_jorge.h
 *
 *  Created on: Sep 17, 2023
 *      Author: 20186244
 */

#ifndef NEMA17_JORGE_H
#define NEMA17_JORGE_H

#include "stm32f4xx_hal.h"
//#include "stm32f3xx_hal.h" nucleo f302r8
//#include "stm32l4xx_hal.h" descomentas si tienes un nucleo l446re

void microDelay(uint16_t delay);
void step(int steps, uint8_t direction, uint16_t delay);

#endif /* NEMA17_JORGE_H */
